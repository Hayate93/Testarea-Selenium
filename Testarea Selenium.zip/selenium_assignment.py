import time

from selenium import webdriver
from selenium.webdriver.common.by import By

opt = webdriver.ChromeOptions()
opt.add_argument('disable-popup-blocking')
driver = webdriver.Chrome(options=opt)
driver.get("http://www.google.com")

time.sleep(2)  # so that the buttons load

elems = driver.find_elements(By.TAG_NAME, "button")
for elem in elems:
    if elem.text.lower().find('accept') != -1:
        elem.click()
        break

inputs = driver.find_elements(By.CSS_SELECTOR, 'input[type=text]')
search_bar = inputs[0]

# type into the search bar
search_bar.send_keys('facebook')

# find the search button
btn_inputs = driver.find_elements(By.CSS_SELECTOR, 'input[role=button]')

search_button = btn_inputs[1]
search_button.click()

# find the first link which contains facebook inside it
all_links = driver.find_elements(By.TAG_NAME, 'a')
facebook_link = None
for link in all_links:
    if link.text == 'Log In':
        facebook_link = link
        break
print(facebook_link.get_attribute('href'))
facebook_link.click()

time.sleep(2)

allow_cookies_btn = None
for btn in driver.find_elements(By.TAG_NAME, 'button'):
    if btn.value_of_css_property('color') == 'rgba(255, 255, 255, 1)':
        allow_cookies_btn = btn

allow_cookies_btn.click()

email_input = driver.find_element(By.CSS_SELECTOR, 'input[type=text]')
password_input = driver.find_element(By.CSS_SELECTOR, 'input[type=password]')
login_button = driver.find_element(By.ID, 'loginbutton')

email_input.send_keys('meta@facebook.com')
password_input.send_keys('unbreakable')

login_button.click()

time.sleep(10)

# find the email container message
try:
    email_container_error_message = driver.find_element(By.CSS_SELECTOR, '#email_container>:last-child')
    # if not email_container_error_message:
    assert email_container_error_message.text.find(
        'The email you entered isn\'t connected to an account') == -1, 'Nu am gasit mesajul de eroare'
except:
    assert False, 'Nu am gasit mesajul de eroare'  # Dam eroare, pentru ca nu am gasit mesajul

print("Am gasit mesajul de eroare la autentificare!")

driver.close()
